# File: android/app/src/main/java/com/mydiabin/app/ui/components/MessageBubble.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mydiabin.app.ui.screens.Message
import com.mydiabin.app.ui.theme.AmberPalette
import com.mydiabin.app.ui.theme.IndigoPalette

@Composable
fun MessageBubble(message: Message) {
    val backgroundColor = if (message.sentByMe) AmberPalette.primary else IndigoPalette.primary
    val textColor = if (message.sentByMe) Color.Black else Color.White
    val alignment = if (message.sentByMe) Alignment.End else Alignment.Start

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .background(backgroundColor, shape = RoundedCornerShape(12.dp))
                .padding(12.dp)
                .align(alignment)
        ) {
            Text(
                text = message.text,
                color = textColor,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "12:34", // mock timestamp
                color = textColor.copy(alpha = 0.6f),
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}