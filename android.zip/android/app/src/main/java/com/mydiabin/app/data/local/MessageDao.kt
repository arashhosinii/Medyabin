# File: android/app/src/main/java/com/mydiabin/app/data/local/MessageDao.kt
package com.mydiabin.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun getMessagesForChat(chatId: String): Flow<List<Message>>

    @Insert
    suspend fun insertMessage(message: Message)
}