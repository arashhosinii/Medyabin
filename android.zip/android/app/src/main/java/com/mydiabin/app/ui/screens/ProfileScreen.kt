# File: android/app/src/main/java/com/mydiabin/app/ui/screens/ProfileScreen.kt
package com.mydiabin.app.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.components.ProfileHeader
import com.mydiabin.app.ui.components.YadgariGrid
import com.mydiabin.app.ui.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Posts", "Reels", "Yadgari")
    var showWelcomeDialog by remember { mutableStateOf(false) }

    // Check isNewUser
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("mydiabin_prefs", Context.MODE_PRIVATE)
        val isNew = prefs.getBoolean("isNewUser", false)
        showWelcomeDialog = isNew
    }

    if (showWelcomeDialog) {
        AlertDialog(
            onDismissRequest = { /* prevent dismissal */ },
            title = { Text("Welcome Zana") },
            text = { Text("به مایدیابین خوش اومدی! من زانا هستم، مشاور و دوست تو. لطفاً پروفایلت رو کامل کن تا بتونم بهتر کمکت کنم.") },
            confirmButton = {
                TextButton(onClick = {
                    // Navigate to EditProfile (simple form) or close dialog
                    showWelcomeDialog = false
                    context.getSharedPreferences("mydiabin_prefs", Context.MODE_PRIVATE)
                        .edit().putBoolean("isNewUser", false).apply()
                    // Show basic edit profile (we'll just navigate to settings for now)
                    navController.navigate(Screen.Settings.route)
                }) {
                    Text("Complete Profile")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("arash.hoseini") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                        Icon(Icons.Default.Menu, contentDescription = "Settings")
                    }
                },
                actions = {
                    // Verified ring
                    Icon(
                        Icons.Default.Verified,
                        contentDescription = "Verified",
                        tint = Color(0xFFFFB300)
                    )
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            ProfileHeader(
                username = "@arash.hoseini",
                bio = "خالق داستان‌های دیجیتال",
                posts = 21,
                followers = 185,
                following = 148
            )
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }
            when (selectedTab) {
                0 -> PostsGrid()
                1 -> ReelsGrid()
                2 -> YadgariGrid()
            }
        }
    }
}

@Composable
fun PostsGrid() {
    // Placeholder grid of 9 items
    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(300.dp)) {
        items(9) {
            Card(modifier = Modifier.padding(2.dp).fillMaxWidth().height(100.dp), colors = CardDefaults.cardColors(Color.LightGray))
        }
    }
}

@Composable
fun ReelsGrid() {
    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(300.dp)) {
        items(4) {
            Card(modifier = Modifier.padding(2.dp).fillMaxWidth().height(150.dp), colors = CardDefaults.cardColors(Color.DarkGray))
        }
    }
}

@Composable
fun YadgariGrid() {
    Column(modifier = Modifier.padding(8.dp)) {
        Text("Saved by Mana", style = MaterialTheme.typography.titleSmall)
        LazyVerticalGrid(columns = GridCells.Fixed(2)) {
            items(4) {
                Card(modifier = Modifier.padding(2.dp).fillMaxWidth().height(80.dp), colors = CardDefaults.cardColors(Color.Green.copy(alpha=0.3f)))
            }
        }
        Text("Inspiration", style = MaterialTheme.typography.labelMedium)
    }
}