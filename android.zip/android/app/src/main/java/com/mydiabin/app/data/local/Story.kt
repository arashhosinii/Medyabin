# File: android/app/src/main/java/com/mydiabin/app/data/local/Story.kt
package com.mydiabin.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class Story(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val imageUri: String?,
    val audioUri: String?,
    val isSeen: Boolean,
    val timestamp: Long
)