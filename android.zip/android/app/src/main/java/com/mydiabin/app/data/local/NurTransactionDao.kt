# File: android/app/src/main/java/com/mydiabin/app/data/local/NurTransactionDao.kt
package com.mydiabin.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NurTransactionDao {
    @Query("SELECT * FROM nur_transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsForUser(userId: Int): Flow<List<NurTransaction>>

    @Insert
    suspend fun insertTransaction(transaction: NurTransaction)
}