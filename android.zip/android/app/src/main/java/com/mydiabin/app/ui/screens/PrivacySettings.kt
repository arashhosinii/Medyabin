# File: android/app/src/main/java/com/mydiabin/app/ui/screens/PrivacySettings.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettings(navController: NavController) {
    var isPrivate by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Privacy Settings") })
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Private Account")
                Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
            }
            Text(
                "When set to private, only approved followers can see your content.",
                style = MaterialTheme.typography.bodySmall
            )
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            // Add more toggles for story hiding, etc.
        }
    }
}