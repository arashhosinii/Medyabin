# File: android/app/src/main/java/com/mydiabin/app/util/NetworkUtil.kt
package com.mydiabin.app.util

import java.net.HttpURLConnection
import java.net.URL

object NetworkUtil {
    fun isBackendReachable(): Boolean {
        return try {
            val url = URL("http://localhost:8000/health")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.responseCode == 200
        } catch (e: Exception) {
            false
        }
    }
}