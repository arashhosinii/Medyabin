# File: android/app/src/main/java/com/mydiabin/app/ui/screens/ChatScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.components.MessageBubble
import com.mydiabin.app.ui.theme.AmberPalette
import com.mydiabin.app.ui.theme.IndigoPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    navController: NavController,
    username: String? = "hafan.wp"
) {
    var message by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            Message("Hello!", true),
            Message("How are you?", false)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(username ?: "Chat") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Aura dot of partner
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(AmberPalette.primary, shape = CircleShape)
                    )
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a message...") }
                )
                IconButton(onClick = {
                    if (message.isNotBlank()) {
                        // mock Dadras check: if message contains "badword", block
                        if (!message.contains("badword", ignoreCase = true)) {
                            messages.add(Message(message, true))
                            message = ""
                        } else {
                            // show overlay
                        }
                    }
                }) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                }
                IconButton(onClick = { /* voice message */ }) {
                    Text("🎤")
                }
            }
        }
    ) { padding ->
        val aura = AmberPalette.primary // mock partner aura
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(aura.copy(alpha = 0.05f))
        ) {
            LazyColumn(modifier = Modifier.padding(8.dp)) {
                items(messages) { msg ->
                    MessageBubble(msg)
                }
            }
        }
    }
}

data class Message(val text: String, val sentByMe: Boolean)