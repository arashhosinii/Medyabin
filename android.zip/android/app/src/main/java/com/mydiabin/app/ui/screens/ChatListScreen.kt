# File: android/app/src/main/java/com/mydiabin/app/ui/screens/ChatListScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.theme.AmberPalette
import com.mydiabin.app.ui.theme.IndigoPalette
import com.mydiabin.app.ui.theme.LocalAuraColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(navController: NavController) {
    val auraColors = LocalAuraColors.current
    // Mock conversations
    val conversations = remember {
        listOf(
            ChatItem("Sina Ghorbanpour", "Sent a reel", true),
            ChatItem("hafan.wp", "Liked a message", false),
            ChatItem("Kamyar Molani", "Sent", true),
            ChatItem("Maryam Rafiei", "Sent", false)
        )
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { /* new chat */ }) {
                Icon(Icons.Default.Add, contentDescription = "New chat")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding)
        ) {
            items(conversations) { chat ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { navController.navigate("chat/${chat.username}") }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Avatar placeholder
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.Gray),
                        contentAlignment = Alignment.Center
                    ) { Text("👤") }

                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(chat.username, style = MaterialTheme.typography.bodyLarge)
                        Text(chat.lastMessage, style = MaterialTheme.typography.bodySmall)
                    }
                    // Aura dot
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(
                                if (chat.isOnline) AmberPalette.primary else IndigoPalette.primary,
                                shape = CircleShape
                            )
                    )
                }
            }
        }
    }
}

data class ChatItem(
    val username: String,
    val lastMessage: String,
    val isOnline: Boolean
)