# File: android/app/src/main/java/com/mydiabin/app/ui/screens/NewPostScreen.kt
package com.mydiabin.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun NewPostScreen(navController: NavController) {
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var aiLabel by remember { mutableStateOf(false) }
    var location by remember { mutableStateOf("") }
    var poll by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> imageUri = uri }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Image picker
        Button(onClick = { galleryLauncher.launch("image/*") }) {
            Text("Pick Image")
        }
        imageUri?.let {
            // Preview placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Text("Image Preview")
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text("Caption") },
            modifier = Modifier.fillMaxWidth()
        )

        // Poll, Prompt, Tag, Location, AI label toggles
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            OutlinedTextField(
                value = poll,
                onValueChange = { poll = it },
                label = { Text("Add poll") },
                modifier = Modifier.fillMaxWidth().menuAnchor(),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                DropdownMenuItem(text = { Text("Yes/No") }, onClick = { poll = "Yes/No"; expanded = false })
                DropdownMenuItem(text = { Text("A/B") }, onClick = { poll = "A/B"; expanded = false })
            }
        }
        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Prompt") })
        OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Add location") })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = aiLabel, onCheckedChange = { aiLabel = it })
            Text("Add AI label")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { /* save post to Room */ navController.popBackStack() }) {
            Text("Share")
        }
    }
}