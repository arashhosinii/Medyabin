# File: android/app/src/main/java/com/mydiabin/app/ui/components/BottomNavigation.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.navigation.Screen

@Composable
fun BottomNavigationBar(
    navController: NavController,
    onCreationHubClick: () -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Screen.Home.route) },
            icon = { Text("🏠") },
            label = { Text("Home") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Screen.Explore.route) },
            icon = { Text("🔍") },
            label = { Text("Explore") }
        )
        // Central + button with aura ring
        NavigationBarItem(
            selected = false,
            onClick = { onCreationHubClick() },
            icon = {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .padding(4.dp)
                ) {
                    AuraButton(onClick = { onCreationHubClick() }) {
                        Text("+", style = MaterialTheme.typography.titleLarge)
                    }
                }
            },
            label = { Text("Create") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Screen.Chat.route) },
            icon = { Text("💬") },
            label = { Text("Chat") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate(Screen.Profile.route) },
            icon = { Text("👤") },
            label = { Text("Profile") }
        )
    }
}