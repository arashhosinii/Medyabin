# File: android/app/src/main/java/com/mydiabin/app/ui/components/CreationHub.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreationHub(
    navController: NavController,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { navController.navigate(Screen.NewPost.route); onDismiss() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("POST")
            }
            Button(
                onClick = { navController.navigate("story_camera"); onDismiss() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("STORY")
            }
            Button(
                onClick = { navController.navigate("camera"); onDismiss() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("REEL")
            }
            Button(
                onClick = { /* live */ onDismiss() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("LIVE")
            }
        }
    }
}