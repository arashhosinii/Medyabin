# File: android/app/src/main/java/com/mydiabin/app/ui/components/LoadingIndicator.kt
package com.mydiabin.app.ui.components

import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import com.mydiabin.app.ui.theme.LocalAuraColors

@Composable
fun LoadingIndicator() {
    CircularProgressIndicator(
        color = LocalAuraColors.current.primary
    )
}