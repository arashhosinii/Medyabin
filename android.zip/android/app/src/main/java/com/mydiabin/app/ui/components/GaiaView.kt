# File: android/app/src/main/java/com/mydiabin/app/ui/components/GaiaView.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

@Composable
fun GaiaView() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Placeholder map with glowing dots
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(Color(0xFF212121)),
                contentAlignment = Alignment.Center
            ) {
                // Draw several glowing dots
                val dots = List(10) { IndexedValue(it, Random.nextFloat() * 100, Random.nextFloat() * 100) }
                dots.forEach { (_, x, y) ->
                    Box(
                        modifier = Modifier
                            .offset(x = x.dp, y = y.dp)
                            .size(8.dp)
                            .background(Color.Green.copy(alpha = 0.8f), shape = CircleShape)
                    )
                }
                Text("🌍", fontSize = 40.sp)
            }
            Text(
                text = "Gaia's Lens - Coming soon",
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}