# File: android/app/src/main/java/com/mydiabin/app/data/local/UserDao.kt
package com.mydiabin.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE token IS NOT NULL LIMIT 1")
    suspend fun getFirstToken(): User?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Query("UPDATE users SET token = :token WHERE id = 1")
    suspend fun insertOrUpdateToken(token: String)

    @Query("SELECT EXISTS(SELECT 1 FROM users WHERE username = :username)")
    suspend fun isUsernameTaken(username: String): Boolean

    @Query("SELECT * FROM users WHERE id = 1")
    fun getUser(): Flow<User?>

    @Update
    suspend fun updateUser(user: User)
}