# File: android/app/src/main/java/com/mydiabin/app/ui/screens/HomeScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.components.DailyDashboard
import com.mydiabin.app.ui.components.PostCard
import com.mydiabin.app.ui.components.StoriesBar
import com.mydiabin.app.ui.navigation.Screen
import com.mydiabin.app.viewmodels.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = remember { HomeViewModel() } // placeholder ViewModel
) {
    val posts by viewModel.posts.collectAsState()
    var refreshing by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mydiabin") },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.StoryViewer.route) }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            item { StoriesBar(navController) }
            item { DailyDashboard() }
            items(posts) { post ->
                PostCard(post, onClick = { /* open detail */ })
            }
        }
        // Pull-to-refresh (basic approach)
        if (refreshing) {
            LaunchedEffect(Unit) {
                // viewModel.refreshPosts()
                refreshing = false
            }
        }
    }
}