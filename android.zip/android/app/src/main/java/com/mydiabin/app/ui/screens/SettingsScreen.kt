# File: android/app/src/main/java/com/mydiabin/app/ui/screens/SettingsScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.theme.LocalAuraColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    val auraColors = LocalAuraColors.current
    val context = LocalContext.current
    var showLanguageDialog by remember { mutableStateOf(false) }
    var selectedLanguage by remember { mutableStateOf("English") }
    val languages = listOf("English", "فارسی", "کوردی", "Türkçe", "العربية")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Aura & Privacy
            SettingsGroup(title = "Aura & Privacy") {
                SettingsItem("Account privacy", "Public") { /* navigate to privacy */ }
                SettingsItem("Close Friends (Hamraz)", "2") { /* manage */ }
                SettingsItem("Blocked (Tarik Shodegan)", "0") { /* manage */ }
                SettingsItem("Hide story & live", "") { /* manage */ }
                SettingsItem("Activity status", "On") { /* toggle */ }
            }
            // Interactions
            SettingsGroup(title = "Interactions") {
                SettingsItem("Messages", "") { /* navigate */ }
                SettingsItem("Tags and mentions", "") { /* */ }
                SettingsItem("Comments (Dadras strictness)", "Medium") { /* slider */ }
                SettingsItem("Sharing and reuse", "") { /* */ }
                SettingsItem("Restricted", "0") { /* */ }
            }
            // Content & Language
            SettingsGroup(title = "Content & Language") {
                SettingsItem("Language", selectedLanguage) {
                    showLanguageDialog = true
                }
                SettingsItem("Hejar cultural filter", "Off") { /* toggle */ }
            }
            // Your Activity
            SettingsGroup(title = "Your Activity") {
                SettingsItem("Aura Report", "") { /* show chart */ }
                SettingsItem("Time Management", "Daily limit: 2h") { /* set */ }
                SettingsItem("Nûr Wallet", "1250 Nûr") {
                    navController.navigate("nur_wallet")
                }
            }
            // Support & About
            SettingsGroup(title = "Support & About") {
                SettingsItem("Help", "") { /* */ }
                SettingsItem("Privacy Center", "") { /* */ }
                SettingsItem("Account Status", "") { /* */ }
                SettingsItem("About Mydiabin", "v1.0") { /* */ }
            }
        }

        if (showLanguageDialog) {
            AlertDialog(
                onDismissRequest = { showLanguageDialog = false },
                title = { Text("Select Language") },
                text = {
                    Column {
                        languages.forEach { lang ->
                            Text(
                                text = lang,
                                modifier = Modifier
                                    .clickable {
                                        selectedLanguage = lang
                                        showLanguageDialog = false
                                    }
                                    .padding(8.dp)
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showLanguageDialog = false }) {
                        Text("Done")
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        modifier = Modifier.padding(16.dp)
    )
    Column(modifier = Modifier.padding(horizontal = 16.dp), content = content)
    Divider()
}

@Composable
fun SettingsItem(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(subtitle, style = MaterialTheme.typography.bodySmall)
    }
}