# File: android/app/src/main/java/com/mydiabin/app/data/local/StoryDao.kt
package com.mydiabin.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories ORDER BY timestamp DESC")
    fun getAllStories(): Flow<List<Story>>

    @Insert
    suspend fun insertStory(story: Story)
}