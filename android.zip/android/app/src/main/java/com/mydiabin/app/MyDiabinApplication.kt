# File: android/app/src/main/java/com/mydiabin/app/MyDiabinApplication.kt
package com.mydiabin.app

import android.app.Application

class MyDiabinApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialization (e.g., Room, DataStore) will be handled by DI later
    }
}