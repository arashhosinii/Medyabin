# File: android/app/src/main/java/com/mydiabin/app/ui/components/AuraButton.kt
package com.mydiabin.app.ui.components

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.mydiabin.app.ui.theme.LocalAuraColors

@Composable
fun AuraButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val auraColors = LocalAuraColors.current
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = auraColors.primary,
            contentColor = auraColors.onPrimary
        )
    ) {
        content()
    }
}