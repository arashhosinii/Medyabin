# File: android/app/src/main/java/com/mydiabin/app/data/local/Message.kt
package com.mydiabin.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chatId: String,
    val senderUsername: String,
    val text: String,
    val timestamp: Long,
    val isVoice: Boolean
)