# File: android/app/src/main/java/com/mydiabin/app/ui/screens/StoryCamera.kt
package com.mydiabin.app.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun StoryCamera(navController: androidx.navigation.NavController) {
    val context = LocalContext.current
    var hasAudioPermission by remember { mutableStateOf(false) }
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
    }

    LaunchedEffect(Unit) {
        audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Story Camera", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { /* Whisper Story (voice-only) */ }) {
            Text("Whisper Story 🎤")
        }
        if (hasAudioPermission) {
            // Waveform animation placeholder
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .padding(16.dp)
            ) {
                Text("🎵 Recording...")
            }
        }
    }
}