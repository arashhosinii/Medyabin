// # File: android/app/src/main/java/com/mydiabin/app/viewmodels/HomeViewModel.kt
package com.mydiabin.app.viewmodels

import androidx.lifecycle.ViewModel
import com.mydiabin.app.data.local.Post
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class HomeViewModel : ViewModel() {
    private val _posts = MutableStateFlow<List<Post>>(emptyList())
    val posts: StateFlow<List<Post>> = _posts.asStateFlow()

    init {
        _posts.value = listOf(
            Post(1, 1, "arash.hoseini", "", "Beautiful day!", 23, 5, "amber", "2026-05-08", false),
            Post(2, 2, "Sina", "", "Check my new reel", 45, 8, "indigo", "2026-05-07", false)
        )
    }
}