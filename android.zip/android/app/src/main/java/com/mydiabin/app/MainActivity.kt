# File: android/app/src/main/java/com/mydiabin/app/MainActivity.kt
package com.mydiabin.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.mydiabin.app.ui.navigation.NavGraph
import com.mydiabin.app.ui.theme.AuraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AuraTheme {
                NavGraph()
            }
        }
    }
}