# File: android/app/src/main/java/com/mydiabin/app/ui/theme/AuraTheme.kt
package com.mydiabin.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.mydiabin.app.service.AuraSensorService
import java.util.Calendar

val LocalAuraColors = staticCompositionLocalOf<AuraColors> {
    amberAuraColors()
}

@Composable
fun AuraTheme(
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    // Observe sensor state (mock)
    val auraModeState = AuraSensorService.auraMode.collectAsState()
    val sensorMode = auraModeState.value

    // Determine time-based aura
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val timeBasedAura = if (hour in 6..20) amberAuraColors() else indigoAuraColors()

    // Override with sensor if active/focus
    val auraColors = when (sensorMode) {
        AuraSensorService.AuraMode.ACTIVE -> amberAuraColors()
        AuraSensorService.AuraMode.FOCUS -> indigoAuraColors()
        else -> timeBasedAura
    }

    val colorScheme = lightColorScheme(
        primary = auraColors.primary,
        onPrimary = auraColors.onPrimary,
        surface = auraColors.surface,
        onSurface = auraColors.onSurface,
        background = auraColors.background,
        outline = auraColors.outline
    )

    CompositionLocalProvider(LocalAuraColors provides auraColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = DefaultTypography
        ) {
            content()
        }
    }
}