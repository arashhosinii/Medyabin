# File: android/app/src/main/java/com/mydiabin/app/data/local/NurTransaction.kt
package com.mydiabin.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "nur_transactions")
data class NurTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val amount: Int,
    val description: String,
    val timestamp: Long
)