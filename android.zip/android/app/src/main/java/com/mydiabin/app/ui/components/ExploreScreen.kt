# File: android/app/src/main/java/com/mydiabin/app/ui/screens/ExploreScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.components.GaiaView
import com.mydiabin.app.ui.components.MoodChips
import com.mydiabin.app.ui.components.SearchBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(navController: NavController) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("For You", "Castles", "Music", "Helmtî")
    var gaiaVisible by remember { mutableStateOf(false) }
    var rewiMode by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        SearchBar(query = "") { /* filter */ }
        MoodChips(selectedMood = null) { /* filter */ }
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title) }
                )
            }
        }
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                0 -> {
                    // For You: staggered grid
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(20) {
                            Card(
                                modifier = Modifier
                                    .padding(4.dp)
                                    .fillMaxWidth()
                                    .height(120.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.LightGray)
                            ) {
                                Text("GIF/Reel $it")
                            }
                        }
                    }
                }
                else -> {
                    Text("Other tabs content (mock)")
                }
            }
            // Right side icons
            Column(
                modifier = Modifier
                    .align(androidx.compose.ui.Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                IconButton(onClick = { gaiaVisible = !gaiaVisible }) {
                    Text("🗺️")
                }
                IconButton(onClick = { rewiMode = !rewiMode }) {
                    Text("👻")
                }
                IconButton(onClick = { /* oracle */ }) {
                    Text("🔮")
                }
            }
            if (gaiaVisible) {
                GaiaView()
            }
            if (rewiMode) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A237E))
                ) {
                    Text(
                        "You are invisible. Exploring world content.",
                        color = Color.White,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}