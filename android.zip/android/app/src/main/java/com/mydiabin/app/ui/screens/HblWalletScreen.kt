# File: android/app/src/main/java/com/mydiabin/app/ui/screens/HblWalletScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HblWalletScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Nûr Wallet") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Balance", style = MaterialTheme.typography.labelSmall)
                        Text("1,250 Nûr", style = MaterialTheme.typography.headlineLarge)
                    }
                }
            }
            item { Divider(modifier = Modifier.padding(vertical = 8.dp)) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { /* earn */ }) { Text("Earn Nûr") }
                    Button(onClick = { /* spend */ }) { Text("Spend Nûr") }
                }
            }
            item { Spacer(modifier = Modifier.height(16.dp)) }
            items(listOf("+50 Daily Login", "-200 Castle Upgrade", "+120 Chat Mission")) { tx ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(tx, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}