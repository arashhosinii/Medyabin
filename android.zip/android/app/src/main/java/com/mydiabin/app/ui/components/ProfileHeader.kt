# File: android/app/src/main/java/com/mydiabin/app/ui/components/ProfileHeader.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mydiabin.app.ui.theme.LocalAuraColors

@Composable
fun ProfileHeader(
    username: String,
    bio: String,
    posts: Int,
    followers: Int,
    following: Int
) {
    val auraColors = LocalAuraColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar with Aura ring
        Box(modifier = Modifier.size(80.dp)) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
            )
            Box(
                modifier = Modifier
                    .size(84.dp)
                    .offset((-2).dp, (-2).dp)
                    .clip(CircleShape)
                    .background(auraColors.primary.copy(alpha = 0.3f))
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(username, style = MaterialTheme.typography.titleMedium)
            Text(bio, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$posts")
                    Text("Posts", style = MaterialTheme.typography.labelSmall)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$followers")
                    Text("Followers", style = MaterialTheme.typography.labelSmall)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$following")
                    Text("Following", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(onClick = { /* edit profile */ }) { Text("Edit Profile") }
        OutlinedButton(onClick = { /* share */ }) { Text("Share Profile") }
    }
}