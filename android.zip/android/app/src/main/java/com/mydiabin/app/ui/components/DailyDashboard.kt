# File: android/app/src/main/java/com/mydiabin/app/ui/components/DailyDashboard.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mydiabin.app.ui.theme.LocalAuraColors

@Composable
fun DailyDashboard() {
    val auraColors = LocalAuraColors.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        colors = CardDefaults.cardColors(containerColor = auraColors.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Nûra Roj", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text("You earned 150 Nûr today!")
            Spacer(modifier = Modifier.height(12.dp))
            Text("Jin's Mission: Chat with 3 friends to open a treasure chest.", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🌱 Gaia Garden")
                Spacer(modifier = Modifier.width(8.dp))
                LinearProgressIndicator(
                    progress = 0.4f,
                    modifier = Modifier.weight(1f),
                    color = Color(0xFF4CAF50)
                )
            }
        }
    }
}