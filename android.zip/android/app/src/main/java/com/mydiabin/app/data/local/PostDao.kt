# File: android/app/src/main/java/com/mydiabin/app/data/local/PostDao.kt
package com.mydiabin.app.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY timestamp DESC")
    fun getAllPosts(): Flow<List<Post>>

    @Insert
    suspend fun insertPost(post: Post)
}