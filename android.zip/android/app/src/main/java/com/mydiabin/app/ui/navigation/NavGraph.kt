# File: android/app/src/main/java/com/mydiabin/app/ui/navigation/NavGraph.kt
package com.mydiabin.app.ui.navigation

import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mydiabin.app.ui.components.CreationHub
import com.mydiabin.app.ui.screens.*
import com.mydiabin.app.ui.screens.auth.LoginScreen
import com.mydiabin.app.ui.screens.auth.RegisterScreen

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object Explore : Screen("explore")
    object Chat : Screen("chat")
    object Profile : Screen("profile")
    object Settings : Screen("settings")
    object StoryViewer : Screen("story_viewer")
    object NewPost : Screen("new_post")
    object Admin : Screen("admin")
    object Camera : Screen("camera")
    object StoryCamera : Screen("story_camera")
    object NurWallet : Screen("nur_wallet")
    object PrivacySettings : Screen("privacy_settings")
    object ChatDetail : Screen("chat/{username}") {
        fun createRoute(username: String) = "chat/$username"
    }
}

@Composable
fun NavGraph(
    navController: NavHostController = rememberNavController()
) {
    var showCreationHub by remember { mutableStateOf(false) }

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) { SplashScreen(navController) }
        composable(Screen.Login.route) { LoginScreen(navController) }
        composable(Screen.Register.route) { RegisterScreen(navController) }
        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.Explore.route) { ExploreScreen(navController) }
        composable(Screen.Chat.route) { ChatListScreen(navController) }
        composable(Screen.Profile.route) { ProfileScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }
        composable(Screen.NewPost.route) { NewPostScreen(navController) }
        composable(Screen.Admin.route) { AdminPanelScreen(navController) }
        composable(Screen.Camera.route) { CameraScreen(navController) }
        composable(Screen.StoryCamera.route) { StoryCamera(navController) }
        composable(Screen.NurWallet.route) { HblWalletScreen(navController) }
        composable(Screen.PrivacySettings.route) { PrivacySettings(navController) }
        composable(
            Screen.ChatDetail.route,
            arguments = listOf(navArgument("username") { defaultValue = "hafan.wp" })
        ) { backStackEntry ->
            val username = backStackEntry.arguments?.getString("username") ?: "hafan.wp"
            ChatScreen(navController, username)
        }
    }

    if (showCreationHub) {
        CreationHub(
            navController = navController,
            onDismiss = { showCreationHub = false }
        )
    }
}