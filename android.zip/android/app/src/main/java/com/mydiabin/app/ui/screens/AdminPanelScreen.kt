# File: android/app/src/main/java/com/mydiabin/app/ui/screens/AdminPanelScreen.kt
package com.mydiabin.app.ui.screens

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(navController: androidx.navigation.NavController) {
    val context = LocalContext.current
    // Shake detection (simplified)
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            var lastShake = 0L
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    val x = it.values[0]
                    val y = it.values[1]
                    val z = it.values[2]
                    val acceleration = Math.sqrt((x * x + y * y + z * z).toDouble())
                    if (acceleration > 15.0) {
                        val now = System.currentTimeMillis()
                        if (now - lastShake > 1000) {
                            lastShake = now
                            // Access admin (this screen)
                        }
                    }
                }
            }
            override fun onAccuracyChanged(p0: Sensor?, p1: Int) {}
        }
        sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        onDispose { sensorManager.unregisterListener(listener) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Admin Panel") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            Text("Dashboard", style = MaterialTheme.typography.titleMedium)
            Text("Total Users: 12,450")
            Text("Total Posts: 89,200")
            Text("Nûr in Circulation: 5.2M")
            Spacer(modifier = Modifier.height(16.dp))
            Text("User Management")
            TextField(value = "", onValueChange = {}, placeholder = { Text("Search user...") })
            Spacer(modifier = Modifier.height(8.dp))
            Text("Content Review (flagged by Dadras)")
            Button(onClick = { /* approve all */ }) { Text("Approve All") }
            Spacer(modifier = Modifier.height(8.dp))
            Text("AI Learning Logs")
            Text("Mock log: Diako v0.82 improved command recognition.")
        }
    }
}