# File: android/app/src/main/java/com/mydiabin/app/ui/theme/Color.kt
package com.mydiabin.app.ui.theme

import androidx.compose.ui.graphics.Color

// Amber Palette (active/day)
object AmberPalette {
    val primary = Color(0xFFFFB300)
    val primaryVariant = Color(0xFFFFA000)
    val surface = Color(0xFFFFF8E1)
    val background = Color(0xFFFFFFFF)
    val onPrimary = Color(0xFF000000)
    val onSurface = Color(0xFF212121)
    val outline = Color(0xFFBDBDBD)
}

// Indigo Palette (calm/night)
object IndigoPalette {
    val primary = Color(0xFF1A237E)
    val primaryVariant = Color(0xFF0D1642)
    val surface = Color(0xFFE8EAF6)
    val background = Color(0xFFFAFAFA)
    val onPrimary = Color(0xFFFFFFFF)
    val onSurface = Color(0xFF212121)
    val outline = Color(0xFFBDBDBD)
}

data class AuraColors(
    val primary: Color,
    val primaryVariant: Color,
    val surface: Color,
    val background: Color,
    val onPrimary: Color,
    val onSurface: Color,
    val outline: Color
)

fun amberAuraColors() = AuraColors(
    primary = AmberPalette.primary,
    primaryVariant = AmberPalette.primaryVariant,
    surface = AmberPalette.surface,
    background = AmberPalette.background,
    onPrimary = AmberPalette.onPrimary,
    onSurface = AmberPalette.onSurface,
    outline = AmberPalette.outline
)

fun indigoAuraColors() = AuraColors(
    primary = IndigoPalette.primary,
    primaryVariant = IndigoPalette.primaryVariant,
    surface = IndigoPalette.surface,
    background = IndigoPalette.background,
    onPrimary = IndigoPalette.onPrimary,
    onSurface = IndigoPalette.onSurface,
    outline = IndigoPalette.outline
)