# File: android/app/src/main/java/com/mydiabin/app/ui/components/MoodChips.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoodChips(
    selectedMood: String?,
    onMoodSelected: (String) -> Unit
) {
    val moods = listOf("Happy", "Calm", "Motivated", "Sad", "Angry", "Chill")
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(moods.size) { index ->
            val mood = moods[index]
            FilterChip(
                selected = mood == selectedMood,
                onClick = { onMoodSelected(mood) },
                label = { Text(mood) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = when (mood) {
                        "Happy" -> Color(0xFFFFB300).copy(alpha = 0.2f)
                        "Calm" -> Color(0xFF1A237E).copy(alpha = 0.2f)
                        else -> Color.Gray.copy(alpha = 0.2f)
                    }
                )
            )
        }
    }
}