# File: android/app/src/main/java/com/mydiabin/app/ui/components/StoriesBar.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.ui.theme.AmberPalette
import com.mydiabin.app.ui.theme.IndigoPalette
import com.mydiabin.app.ui.theme.LocalAuraColors

@Composable
fun StoriesBar(navController: NavController) {
    val auraColors = LocalAuraColors.current
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Your Story
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.Gray.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                // If no active story -> + icon
                Text("+", style = MaterialTheme.typography.titleMedium)
                // Outer ring
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(Color.Transparent)
                )
            }
        }
        // Mock user stories
        items(5) {
            val seen = it % 2 == 0 // mock
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (seen) IndigoPalette.primary else AmberPalette.primary),
                contentAlignment = Alignment.Center
            ) {
                Text("U$it", color = Color.White)
            }
        }
        // Rêwî and Live Now
        item {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.DarkGray),
                contentAlignment = Alignment.Center
            ) {
                Text("🌍", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.Red.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                // Pulsing dot
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(Color.Red)
                )
                Text("LIVE", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
    }
}