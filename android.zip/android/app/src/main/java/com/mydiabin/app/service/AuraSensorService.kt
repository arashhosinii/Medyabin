# File: android/app/src/main/java/com/mydiabin/app/service/AuraSensorService.kt
package com.mydiabin.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mydiabin.app.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AuraSensorService : Service(), SensorEventListener {
    companion object {
        val _auraMode = MutableStateFlow(AuraMode.NONE)
        val auraMode: StateFlow<AuraMode> = _auraMode.asStateFlow()
    }

    enum class AuraMode { ACTIVE, FOCUS, NONE }

    private lateinit var sensorManager: SensorManager

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification()
        startForeground(1, notification)

        val lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (it.sensor.type == Sensor.TYPE_LIGHT) {
                val lux = it.values[0]
                // Simple mock: high light -> ACTIVE, low -> FOCUS
                val newMode = if (lux > 100) AuraMode.ACTIVE else AuraMode.FOCUS
                _auraMode.value = newMode
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "aura_channel")
            .setContentTitle("Aura Sensor Active")
            .setContentText("Adapting your Mydiabin experience")
            .setSmallIcon(android.R.drawable.ic_menu_eye)
            .setContentIntent(pendingIntent)
            .build()
    }
}