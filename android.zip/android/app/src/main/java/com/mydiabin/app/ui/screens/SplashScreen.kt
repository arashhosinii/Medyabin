# File: android/app/src/main/java/com/mydiabin/app/ui/screens/SplashScreen.kt
package com.mydiabin.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mydiabin.app.data.local.AppDatabase
import com.mydiabin.app.data.local.UserDao
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

// Mock audio reference: R.raw.diako_whisper (just a comment)
@Composable
fun SplashScreen(navController: NavController) {
    var isAnimating by remember { mutableStateOf(true) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        // Simulate splash duration with Diako whisper
        // MediaPlayer.create(context, R.raw.diako_whisper)?.start()
        delay(2500)
        val db = AppDatabase.getInstance(LocalContext.current)
        val userDao: UserDao = db.userDao()
        val token = userDao.getFirstToken()
        if (token != null) {
            navController.navigate("home") {
                popUpTo("splash") { inclusive = true }
            }
        } else {
            navController.navigate("login") {
                popUpTo("splash") { inclusive = true }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F1A)),
        contentAlignment = Alignment.Center
    ) {
        // Animated sphere with particles
        val rotationAngle by rememberInfiniteTransition().animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(2000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )

        Canvas(modifier = Modifier.size(200.dp)) {
            // Gradient sphere
            val gradientBrush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFB300), Color(0xFF1A237E)),
                center = Offset(size.width / 2, size.height / 2),
                radius = size.minDimension / 2
            )
            rotate(rotationAngle, pivot = Offset(size.width / 2, size.height / 2)) {
                drawCircle(gradientBrush)
            }
            // Floating particles
            repeat(8) {
                val angle = it * 45f + rotationAngle
                val rad = Math.toRadians(angle.toDouble())
                val dx = size.width / 2 + 80 * Math.cos(rad)
                val dy = size.height / 2 + 80 * Math.sin(rad)
                drawCircle(
                    color = Color.White.copy(alpha = 0.6f),
                    radius = 4f,
                    center = Offset(dx.toFloat(), dy.toFloat())
                )
            }
        }

        Text(
            text = "Mydiabin",
            color = Color.White,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 64.dp)
        )
    }
}