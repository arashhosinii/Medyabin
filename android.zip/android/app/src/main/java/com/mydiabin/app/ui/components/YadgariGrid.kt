# File: android/app/src/main/java/com/mydiabin/app/ui/components/YadgariGrid.kt
// Already inline in ProfileScreen, but we can keep the separate composable placeholder.
package com.mydiabin.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun YadgariGrid() {
    Column(modifier = Modifier.padding(8.dp)) {
        Text("Saved by Mana", style = MaterialTheme.typography.titleSmall)
        LazyVerticalGrid(columns = GridCells.Fixed(2)) {
            items(4) {
                Card(
                    modifier = Modifier
                        .padding(2.dp)
                        .fillMaxWidth()
                        .height(80.dp),
                    colors = CardDefaults.cardColors(Color.Green.copy(alpha = 0.3f))
                )
            }
        }
        Text("Inspiration", style = MaterialTheme.typography.labelMedium)
    }
}