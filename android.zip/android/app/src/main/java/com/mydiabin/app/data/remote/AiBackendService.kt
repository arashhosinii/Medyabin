# File: android/app/src/main/java/com/mydiabin/app/data/remote/AiBackendService.kt
package com.mydiabin.app.data.remote

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*

interface AiBackendService {
    @POST("ai/dadras")
    suspend fun checkToxicity(@Body text: ToxicityRequest): ToxicityResponse

    @GET("ai/zana/greeting")
    suspend fun getZanaGreeting(@Query("lang") lang: String): ZanaGreeting

    @POST("ai/newa/translate")
    suspend fun translate(@Body request: TranslationRequest): TranslationResponse

    companion object {
        val instance: AiBackendService by lazy {
            val retrofit = Retrofit.Builder()
                .baseUrl("http://localhost:8000/")
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
            retrofit.create(AiBackendService::class.java)
        }
    }
}

data class ToxicityRequest(val text: String)
data class ToxicityResponse(val status: String, val message: String)
data class ZanaGreeting(val text: String, val audioUri: String)
data class TranslationRequest(val text: String, val targetLang: String)
data class TranslationResponse(val translatedText: String)