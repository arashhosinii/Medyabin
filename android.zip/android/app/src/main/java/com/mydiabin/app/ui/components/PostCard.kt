# File: android/app/src/main/java/com/mydiabin/app/ui/components/PostCard.kt
package com.mydiabin.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mydiabin.app.data.local.Post
import com.mydiabin.app.ui.theme.LocalAuraColors

@Composable
fun PostCard(post: Post, onClick: () -> Unit) {
    val auraColors = LocalAuraColors.current
    var liked by remember { mutableStateOf(false) }
    val energyColor = if (post.energyType == "amber") Color(0xFFFFB300) else Color(0xFF1A237E)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .border(
                BorderStroke(4.dp, energyColor),
                RoundedCornerShape(8.dp)
            ),
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Placeholder avatar
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.Gray)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(post.username, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                Text(post.timestamp, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(modifier = Modifier.height(8.dp))
            // Image placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Text("Image")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { liked = !liked }) {
                    Icon(
                        if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (liked) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurface
                    )
                }
                // Comment and share icons
                IconButton(onClick = { /* comment */ }) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = "Comment") // placeholder
                }
                IconButton(onClick = { /* share */ }) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = "Share")
                }
            }
            Text(post.caption, modifier = Modifier.padding(vertical = 4.dp))
            Text("${post.likeCount} likes  ${post.commentCount} comments", style = MaterialTheme.typography.labelSmall)
        }
    }
}