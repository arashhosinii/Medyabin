# File: android/app/src/main/java/com/mydiabin/app/data/local/User.kt
package com.mydiabin.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val email: String,
    val username: String,
    val passwordHash: String,
    val bio: String,
    val profileImageUri: String,
    val postsCount: Int,
    val followersCount: Int,
    val followingCount: Int,
    val auraState: String,
    val preferredLanguage: String,
    val deepLearningEnabled: Boolean,
    val isVerified: Boolean,
    val token: String?
)