// # File: android/app/src/main/java/com/mydiabin/app/ui/theme/DiwanFont.kt
package com.mydiabin.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontFamily

@Composable
fun diwanFontFamily(): FontFamily {
    return FontFamily.SansSerif
}