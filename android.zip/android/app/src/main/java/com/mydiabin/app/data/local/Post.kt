# File: android/app/src/main/java/com/mydiabin/app/data/local/Post.kt
package com.mydiabin.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class Post(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val username: String,
    val imageUri: String,
    val caption: String,
    val likeCount: Int,
    val commentCount: Int,
    val energyType: String, // "amber" or "indigo"
    val timestamp: String,
    val isAiGenerated: Boolean
)